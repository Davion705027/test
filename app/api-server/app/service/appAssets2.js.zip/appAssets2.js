/*
 * @FilePath: /client-api-doc-server/app/service/appAssets.js
 * @Description: 从static/cp 复制 到public/upload/app/cp
 */

'use strict';

const Service = require('egg').Service;
const fs = require('fs');
const path = require('path');
const fsPromises = fs.promises
const { mkdir } = fsPromises
const moment = require("moment");
const uuid = require("uuid").v1;

class AppAssetsService extends Service {
    
  async scan() {
    const { ctx } = this;
    const params = ctx.request.body;
    const project = params.project // 项目
    if(!project)return; 
    this.project = project

    // 删除操作
    // await this.delete_old_assets()

    // 目标目录 需要读取的目录 /static/cp
    let target_path = path.join('static',project)

    let folder = path.resolve(target_path)    
    // 递归读取目标文件夹
    await this.readDirectoryContents(folder,target_path)
 
  }
  async create(){
    const { ctx } = this;
    const files = ctx.request.files;
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      await this.create2(file)
    }
  }
  async create2(file){
    const { ctx } = this;
    let request_obj = ctx.request.body;
    const { project,mark } = request_obj
    if(!request_obj.path)return;
    this.project = project

    const oldPath = file.filepath
    let file_name = file.filename
   
    // 检查要写入的newPath文件是否存在文件夹
    // 创建文件夹
    const file_path = path.resolve(this.get_project_path(),path.join(request_obj.path,file_name))
    const dir_path = path.dirname(file_path)
    // console.log(dir_path);
    await mkdir(dir_path, { recursive: true });

     // static/public/upload/...
     const newPath = path.join(dir_path, file_name)
     // 服务器存储路径 /public/upload/...
     const url = newPath.split('static')[1]
 

    // 复制文件
    await fsPromises.copyFile(oldPath, newPath);

  
    let final_obj = {
      name:file_name,
      url,
      path: path.join(request_obj.path,file_name),
      project
    }
    console.log(final_obj);

    await this.service.jwt.add_operator(final_obj);
    // 服务器是否已存在
    const find_one = await this.ctx.model.AppAssets.findOne({path:request_obj.path})
    if(find_one){
      await this.ctx.model.AppAssets.updateOne({path:request_obj.path},{...final_obj})
    }else{
      await this.ctx.model.AppAssets.create(final_obj)
    }

  }
  
  /**
   * 递归读取文件夹
   * @param {String} directoryPath 文件路径
   * @param {String} father_path 父级相对文件路径 
   */
  async readDirectoryContents(directoryPath,father_path) {
    const paths = fs.readdirSync(directoryPath);
    for (const _path of paths) {
    //   console.log(father_path + _path);  // 绝对路径 /static/cp/xx

      const filePath = path.join(directoryPath, _path);
      const stat = fs.statSync(filePath);
      if (stat.isFile()) {  

        // const file_type = this.get_file_type(filePath)
        // const save_target = await this.getUploadFile(filePath,file_type)

        // console.log(filePath); // Users/admin/Desktop/code/full-stack/client-api-doc-server/static/cp/xx/10004.png
        const oldPath = filePath; // /Users/.../static/cp/xx/10004.png
        // const newPath = save_target.filepath;
    

        // 获取项目的原路径  xx/10004.png
        const origin_path = oldPath.split(this.project + '/')[1]
        // static/public/upload/...
        const newPath = path.resolve(this.get_project_path(),origin_path)
        // 服务器存储路径 /public/upload/...
        const url = newPath.split('static')[1]

        // 检查要写入的newPath文件是否存在文件夹
        // 创建文件夹
        const dir_path = path.dirname(newPath)
        await mkdir(dir_path, { recursive: true });


        // 复制文件
        await fsPromises.copyFile(oldPath, newPath);

        console.log(origin_path);
        let final_obj = {
            project:this.project,
            name: path.basename(origin_path),
            path: origin_path, // 原路径
            url, // 服务器存储路径
            // uid: save_target.uid // uid
        }

        // 服务器是否已存在
        const find_one = await this.ctx.model.AppAssets.findOne({url})

        await this.service.jwt.add_operator(final_obj);
        if(find_one) {
          await this.ctx.model.AppAssets.updateOne({path:origin_path},{...final_obj})
        } else{
          await this.ctx.model.AppAssets.create(final_obj)
        }


      } else if (stat.isDirectory()) {
        // 如果是子目录，递归调用
        await this.readDirectoryContents(filePath,father_path + _path);
      }
    }
    }
    // 获取文件类型
    get_file_type(filePath){
        const fileType = path.extname(filePath).toLowerCase();
        if (fileType === '.jpg' || fileType === '.jpeg' || fileType === '.png' || fileType === '.gif') {
            return 'image'
        } else if (fileType === '.mp3') {
            return 'map3'
        } else {
            return 'other'
        }
    }
    get_project_path(){
        const project = this.project;
        const upload_dir = this.config.upload_dir; // static/public/upload/
        const project_path = `${upload_dir}app/${project}/`;  // static/public/upload/app/cp/
        return project_path;
    }
    /**
     * 删除服务器文件夹 和 之前存储的数据
     * static/public/upload/app/cp
     */
    async delete_old_assets(){
        const project = this.project
        const project_path = this.get_project_path()
        const exist = fs.existsSync(project_path)
        if(!exist)return
        await fsPromises.rm(project_path, { recursive: true, force: true })

        const res = await this.ctx.model.AppAssets.deleteMany({project})
        console.log('删除了',res.deletedCount);
    }
    async getUploadFile(filename, type) {
        //获取当前日期
        let day = moment().format("YYYYMMDD");
        console.log(day);

        const project_path = this.get_project_path();
        const basedir = path.join(project_path,type) // static/public/upload/app/cp

        //创建 文件的保存路径 
        let dir = path.join(basedir, day);
        //不存在就创建目录
        await mkdir(dir, { recursive: true });
        //生成uuid 文件名字
        let uid = uuid().replace(/-/ig, '');
        //生成的文件名字
        let save_name = uid + path.extname(filename)
        //完整路径
        let filepath = path.join(dir, save_name);

        const res = {
            uid,
            //完整路径
            filepath,
            //生成的文件名字
            save_name,
            // 保存目录  : this.ctx.origin + uploadDir.slice(3).replace(/\\/g, '/')
            save_filepath: filepath.slice(6).replace(/\\/g, '/'),
        }
        return res
    }
}

module.exports = AppAssetsService;
