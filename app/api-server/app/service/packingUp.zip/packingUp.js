const path = require("path");
const fs = require("fs");
const moment = require("moment");
const Service = require("egg").Service;
class PackingUpService extends Service {
  /**
   * 找到 CSS 设置记录
   * @param {*} detail
   * @returns
   */
  async find_CssKeyConfigRecord(detail) {
    const { version, project } = detail;
    let query = {
      version,
      project,
    };
    let result = await this.ctx.model.CssKeyConfigRecord.find(query);
    return result;
  }
  /**
   * 找到 assets 设置记录
   * @param {*} detail
   * @returns
   */
  async find_AssetsKeyConfigRecord(detail) {
    const { version, project } = detail;
    let query = {
      version,
      project,
    };
    let result = await this.ctx.model.AssetsKeyConfigRecord.find(query);
    return result;
  }
  /**
   * 找到 CSS 自定义设置
   * @param {*} detail
   * @returns
   */
  async find_CssKeyCustomConfig(detail) {
    // 找到 CSS 设置记录
    let cssKeyConfigRecord =
      await this.service.packingUp.find_CssKeyConfigRecord(detail);
    //找到所有的  css 配置 键ID
    let cssKey_ids = [];
    //转对象
    let cssKeyConfigRecord_obj = {};
    cssKeyConfigRecord.map((x) => {
      cssKey_ids.push(x["cssKey_id"]);
      cssKeyConfigRecord_obj[`k_${x["cssKey_id"]}`] = x;
    });
    let query = {
      _id: {
        $in: cssKey_ids,
      },
    };
    //找到配置过的所有的 CSS 的 默认配置
    let default_config = await this.ctx.model.CssKey.find(query);
    let result = [];
    //循环所有默认配置
    default_config.map((x) => {
      // 当前 默认配置的自定义配置
      let obj = cssKeyConfigRecord_obj[`k_${x._id}`];
      //生成实际自定义配置
      result.push({
        key: x.key,
        value: obj.value,
      
      });
    });
    return result;
  }
  /**
   * 找到 assets 自定义设置
   * @param {*} detail
   * @returns
   */
  async find_AssetsKeyCustomRecord(detail) {
    // 找到 CSS 设置记录
    let assetsKeyConfigRecord =
      await this.service.packingUp.find_AssetsKeyConfigRecord(detail);
    //找到所有的  css 配置 键ID
    let assetsKey_ids = [];
    //转对象
    let assetsKeyConfigRecord_obj = {};
    assetsKeyConfigRecord.map((x) => {
      assetsKey_ids.push(x["assetsKey_id"]);
      assetsKeyConfigRecord_obj[`k_${x["assetsKey_id"]}`] = x;
    });
    let query = {
      _id: {
        $in: assetsKey_ids,
      },
    };
    //找到配置过的所有的 CSS 的 默认配置
    let default_config = await this.ctx.model.AssetsKey.find(query);
    let result = [];
    //循环所有默认配置
    default_config.map((x) => {
      // 当前 默认配置的自定义配置
      let obj = assetsKeyConfigRecord_obj[`k_${x._id}`];
      //生成实际自定义配置
      result.push({
        key: x.key,
        day: obj.day,
        night: obj.night,
      });
    });
    return result;
  }
  /**
   * 找到 JS 设置记录
   * @param {*} detail
   * @returns
   */
  async find_JskeyConfigRecord(detail) {
    const { version, project } = detail;
    let query = {
      version,
      project,
    };
    let result = await this.ctx.model.JskeyConfigRecord.find(query);
    return result;
  }
  /**
   * 找到 JS 自定义设置
   * @param {*} detail
   * @returns
   */
  async find_JskeyCustomRecord(detail) {
    // 找到 JS 设置记录
    let jsKeyConfigRecord =
      await this.service.packingUp.find_JskeyConfigRecord(detail);
    // console.log(
    //   "找到 JS 设置记录-------jsKeyConfigRecord--",
    //   jsKeyConfigRecord.length
    // );
    //找到所有的  css 配置 键ID
    let jsKey_ids = [];
    //转对象
    let jsKeyConfigRecord_obj = {};
    jsKeyConfigRecord.map((x) => {
      jsKey_ids.push(x["jsKey_id"]);
      jsKeyConfigRecord_obj[`k_${x["jsKey_id"]}`] = x;
    });
    let query = {
      _id: {
        $in: jsKey_ids,
      },
    };
    // console.log("找到 JS 设置记录-------jsKey_ids--", jsKey_ids);
    //找到配置过的所有的 JS 的 默认配置
    let default_config = await this.ctx.model.Jskey.find(query);
    let result = [];
    //循环所有默认配置
    default_config.map((x) => {
      // 当前 默认配置的自定义配置
      let obj = jsKeyConfigRecord_obj[`k_${x._id}`];
      //生成实际自定义配置
      result.push({
        key: x.key,
        value: obj.value,
      });
    });
    // console.log("找到 JS 设置记录-------result--", result);
    return result;
  }
  /**
   * 找到 CSS  默认 配置
   * @param {*} detail
   * @returns
   */
  async find_CssKeyDefaultConfig(detail) {
    const { project } = detail;
    let query = {
      project,
    };
    let result = await this.ctx.model.CssKey.find(query);
    return result;
  }
  /**
   * 找到 assets  默认 配置
   * @param {*} detail
   * @returns
   */
  async find_AssetsKeyDefaultConfig(detail) {
    const { project } = detail;
    let query = {
      project,
    };
    let result = await this.ctx.model.AssetsKey.find(query);
    return result;
  }
  /**
   * 找到 JS   默认 配置
   * @param {*} detail
   * @returns
   */
  async find_JskeyDefaultConfig(detail) {
    const { project } = detail;
    let query = {
      project,
    };
    let result = await this.ctx.model.Jskey.find(query);
    return result;
  }
  /**
   *  把 数组转对象  css
   */
  change_array_to_obj_by_key_css(arr = [], key = "key") {
    let obj = {};
    arr.map((x) => {
      obj[x[key]] = {
        day: x["day"],
        night: x["night"],
      };
    });
    return obj;
  }
  /**
   *  把 数组转对象  assets
   */
  change_array_to_obj_by_key_assets(arr = [], key = "key") {
    let obj = {};
    arr.map((x) => {
      obj[x[key]] = {
        day: x["day"],
        night: x["night"],
      };
    });
    return obj;
  }
  /**
   *  把 数组转对象  js
   */
  change_array_to_obj_by_key_js(arr = [], key = "key") {
    let obj = {};
    arr.map((x) => {
      obj[x[key]] = x["value"];
    });
    return obj;
  }
  /**
   * 全量或者  差异化  json 写入 文件
   */
  async pack_up_common_write_json_file(detail, pack_up_type, data) {
    // 发起构建的时间
    let puck_up_time = detail.puck_up_time
    // 全版本号
    let full_version = detail.full_version
    // 基础名字
    let base_name = `project_${detail.project}-${full_version}`;
    // 文件全名 ，无 格式
    let full_name = `${base_name}-${pack_up_type}`;
    // 计算文件名字   布局 - 版本号 -
    let filename = `${full_name}.json`;
    // 写入文件
    let write_file_config = {
      data,
      filename,
      type: "json",
      extname: ".json",
    };
    const write_file_result = await this.service.fileExport.write_file(
      write_file_config
    );
    //打包类型  2 用户差异化配置文件
    let info = {
      //发起构建的时间
      puck_up_time,
      // 基础名字
      base_name,
      // 文件全名 ，无 格式
      full_name,
      //打包类型
      type: pack_up_type,
      //day
      day: write_file_result.day,
      // 文件地址   日期202304091045189-uuid版本名字
      path: write_file_result.save_dir,
      //文件名字
      name: write_file_result.filename,
      //type
      type: write_file_result.file_type,
      //打包完成   -1 未完成 1 已完成 -2未完成强制取消
      finish: 1,
    };
    // 更新数据
    if (pack_up_type == 2) {
      detail.type2_info = info;
    }
    if (pack_up_type == 1) {
      detail.type1_info = info;
    }
    await detail.save();
    console.log(`记录打包记录---打包  -${pack_up_type == 1 ? "全量配置" : "差异化"}--json -------`, detail);
  }
  /**
   * 打包
   *
   * 生成打包 记录的 基础数据
   */
  async pack_up_common_create_record(detail) {
    //获取当前日期
    let day = moment().format("YYYYMMDD");
    // 发起构建的时间
    let puck_up_time = Date.now();
    // 全版本号
    let full_version = `${detail.packingConfigId}-${puck_up_time}-${detail.env}`;
    // 记录 打包记录
    let PackingRecord_config = {
      packingConfigId:detail.packingConfigId,
      //打包目标环境  1 试玩 ,2 生产
      env: detail.env,
      //操作人
      operator: detail.operator,
      //操作人ID
      operatorid: detail.operatorid,
      //打包类型  1 全量配置文件 2 用户差异化配置文件， 3.前端代码打包zip 下载  4 js sdk
      type: detail.type,
      //全版本号： 用户自定义版本号  -时间戳，
      full_version,
      //当前日期
      day,
      // 发起构建的时间
      puck_up_time,
      //打包类型  1 全量配置文件
      type1_info: {},
      //打包类型  2 用户差异化配置文件
      type2_info: {},
      //打包类型  3.前端代码打包zip 下载
      type3_info: {},
      //打包类型  4  js sdk
      type4_info: {},
      //备注
      mark: detail.mark,
    };
    //  记录打包记录
    const PackingRecord_result = await this.ctx.model.PackingRecord.create(
      PackingRecord_config
    );
    console.log(
      "记录打包记录----生成打包 记录的 基础数据 -------",
      PackingRecord_result
    );
    return PackingRecord_result;
  }
  // 新旧数据合并
  /**
   *
   * 打包
   *
   * 全量 json
   * @param {*} detail
   */
  async pack_up_common_quanliang_json(detail) {
    //  记录打包记录
    const PackingRecord_result = await this.ctx.model.PackingRecord.findById(
      detail._id
    );
    console.log("记录打包记录----全量 json-------", PackingRecord_result);
    // 找到 CSS  默认配置
    let default_css = await this.service.packingUp.find_CssKeyDefaultConfig(
      detail
    );
    // 找到 CSS 自定义设置
    let config_css = await this.service.packingUp.find_CssKeyCustomConfig(
      detail
    );
    // 找到 JS 默认配置
    let default_js = await this.service.packingUp.find_JskeyDefaultConfig(
      detail
    );
    // 找到 JS 自定义设置
    let config_js = await this.service.packingUp.find_JskeyCustomRecord(
      detail
    );
    // 找到 assets 默认配置
    let default_assets = await this.service.packingUp.find_AssetsKeyDefaultConfig(
      detail
    );
    // 找到 assets 自定义设置
    let config_assets = await this.service.packingUp.find_AssetsKeyCustomRecord(
      detail
    );
    // 把   CSS  默认配置   数组转对象  css
    default_css =
      this.service.packingUp.change_array_to_obj_by_key_css(default_css);
    // 把  CSS 设置记录   数组转对象  css
    config_css =
      this.service.packingUp.change_array_to_obj_by_key_css(config_css);
    // 把  JS 默认配置   数组转对象   js
    default_js =
      this.service.packingUp.change_array_to_obj_by_key_js(default_js);
    // 把  JS 默认配置  数组转对象   js
    config_js = this.service.packingUp.change_array_to_obj_by_key_js(config_js);
    // 把  assets 默认配置   数组转对象   assets
    default_assets =
      this.service.packingUp.change_array_to_obj_by_key_assets(default_assets);
    // 把  assets 默认配置  数组转对象   assets
    config_assets = this.service.packingUp.change_array_to_obj_by_key_assets(config_assets);
    function assign_css(a, b) {
      if (a && b) {
        // a 默认  b 用户配置的
        if (b.day) {
          a.day = b.day;
        }
        if (b.night) {
          a.night = b.night;
        }
      }
    }
    for (let i in config_css) {
      let key = i;
      default_css[key] = assign_css(default_css[key], config_css[key]);
    }
    for (let i in config_assets) {
      let key = i;
      default_assets[key] = assign_css(default_assets[key], config_assets[key]);
    }
    Object.assign(default_js, config_js);
    //文件内容
    let data = {
      pack_up_info: {
        version: detail.version,
        full_version: detail.full_version,
        day: detail.day,
        module_sdk_version: `${detail.day}_${detail.full_version}`,
        //客户端版本
        client_version: 'yazhou'
      },
      css: default_css,
      js: default_js,
      assets: default_assets,
    };
    await this.service.packingUp.pack_up_common_write_json_file(
      detail,
      "1",
      data
    );
  }

  /**
   * 打包    全量 json  新
   * @param {Object} detail 
   */
  async pack_up_common_quanliang_json_new(detail) {
    const ctx = this.ctx;
    //  记录打包记录
    const PackingRecord_result = await this.ctx.model.PackingRecord.findById(
      detail._id
    );
    console.log("记录打包记录----全量 json-------", PackingRecord_result);
    const filter = { project: detail.project, status: 1 }
    const filterRecord = { version: detail.version, project: detail.project, }
    let [css, js, assets, cssRecord, jsRecord, assetsRecord] = await Promise.all([
      ctx.model.CssKey.find(filter),
      ctx.model.Jskey.find(filter),
      ctx.model.AssetsKey.find(filter),

      ctx.model.CssKeyConfigRecord.find(filterRecord),
      ctx.model.JskeyConfigRecord.find(filterRecord),
      ctx.model.AssetsKeyConfigRecord.find(filterRecord),
    ])

    // 将数组转换为字典对象
    const arr2map = (arr, key, cbValue) => arr.reduce((o, v) => {
      o[v[key]] = cbValue(v)
      return o
    }, {})

    cssRecord = arr2map(cssRecord, 'cssKey_id', (v) => ({ day: v.day, night: v.night }))
    assetsRecord = arr2map(assetsRecord, 'assetsKey_id', (v) => ({ day: v.day, night: v.night }))
    jsRecord = arr2map(jsRecord, 'jsKey_id', (v) => v.value)

    // 将数组处理成配置对象
    const handerConfig = (arr, cbValue) => arr.reduce((o, v) => {
      // if (!o[v.project]) o[v.project] = {}
      // o[v.project][v.key] = cbValue(v)
      o[v.key] = cbValue(v)
      return o
    }, {})

    //文件内容
    let data = {
      pack_up_info: {
        version: detail.version,
        full_version: detail.full_version,
        day: detail.day,
        module_sdk_version: `${detail.day}_${detail.full_version}`,
        //客户端版本
        client_version: 'yazhou'
      },
      css: handerConfig(css, (v) => ({ day: cssRecord[v.id] ? cssRecord[v.id].day : v.day, night: cssRecord[v.id] ? cssRecord[v.id].night : v.night, })),
      assets: handerConfig(assets, (v) => ({ day: assetsRecord[v.id] ? assetsRecord[v.id].day : v.day, night: assetsRecord[v.id] ? assetsRecord[v.id].night : v.night, })),
      js: handerConfig(js, (v) => jsRecord[v.id] ? jsRecord[v.id].value : v.value),
    };
    await this.service.packingUp.pack_up_common_write_json_file(
      detail,
      "1",
      data
    );
  }

  /**
   *
   * 打包
   *
   *差异化 json
   * @param {*} detail
   */
  async pack_up_common_chayihua_json(detail) {
    // 找到 CSS 自定义设置
    let result_css = await this.service.packingUp.find_CssKeyCustomConfig(
      detail
    );
    // 找到 JS 自定义设置
    let result_js = await this.service.packingUp.find_JskeyCustomRecord(
      detail
    );
    // 找到 assets 自定义设置
    let result_assets = await this.service.packingUp.find_AssetsKeyCustomRecord(
      detail
    );

    //文件内容
    let data = {

      pack_up_info: {
        version: detail.version,
        full_version: detail.full_version,
        day: detail.day,
        module_sdk_version: `${detail.day}_${detail.full_version}`,
        //客户端版本
        client_version: 'yazhou'
      },
      css: this.service.packingUp.change_array_to_obj_by_key_css(result_css),
      js: this.service.packingUp.change_array_to_obj_by_key_js(result_js),
      assets: this.service.packingUp.change_array_to_obj_by_key_assets(result_assets),
    };
    await this.service.packingUp.pack_up_common_write_json_file(
      detail,
      "2",
      data
    );
  }
  /**
   * 计算需要打包的 数据 并写入 文件
   */
  async pack_up_compute_need_packup(detail) {
    let un_finished = await this.ctx.model.PackingRecord.find({
      $or: [{ "type3_info.finish": -1 }, { "type3_info.finish": null }],
      $and: [{ type: { $regex: "3" } }],
    });
    let len = un_finished.length;
    console.log(
      "un_finished------------un_finished-------",
      un_finished.length
    );
    // console.log("un_finished------------un_finished-------",un_finished);
    //需要打包的
    let need_packup = [];
    // 打包 发起到现在 一个小时 以上的  强制 设置 -2
    let now = Date.now();
    //打包超时
    let timeout_process = [];
    for (let i = 0; i < len; i++) {
      let item = un_finished[i];
      let createdAt = new Date(item.createdAt).getTime();
      //如果时间大于 1小时强制结束
      let gt1 = now - createdAt > 60 * 60 * 1000;
      if (gt1) {
        //记录超时的    //打包请求的 数据库ID
        timeout_process.push(item.id);
        if (!item.type3_info) {
          item.type3_info = {};
        }
        item.type3_info = {
          ...item.type3_info,
          finish: -2,
        };
        await item.save();
        // await this.ctx.model.PackingRecord.findByIdAndUpdate( puck_up_record_id,{ "type3_info.finish" :-2 })
      } else {
        let type2_info = item.type2_info || {};
        need_packup.push({
          //打包请求的 数据库ID
          puck_up_record_id: item._id,
          //时间戳
          timestamp: Date.now(),
          //版本号
          version: item.version,
          //全量版本号
          full_version: item.full_version,
          //布局
          project: item.project,
          //打包类型
          puck_up_type: 3,
          // 打包时间
          puck_up_time: item.puck_up_time,
          //打包事项 任务名字
          puck_up_name: "前端代码打包zip",
          //布局名字
          project_name: item.project == 1 ? "H5" : "PC",
          //基础名字
          base_name: `${type2_info.base_name}`,
          // 运维Jenkins 构建 后打包的 文件名字  不含 .zip
          zip_file_name: `${type2_info.base_name}-3`,
          //zip 文件全名
          zip_file_full_name: `${type2_info.base_name}-3.zip`,
          //前端文件 最后保存路径
          zip_file_full_path: `public/upload/zip/${type2_info.day}/${type2_info.base_name}-3.zip`,
          // 运维Jenkins 构建参数
          jenkins_param_version: `${type2_info.day}_${type2_info.base_name}`,
          //运维 上传 服务器回传目录
          upload_folder: `/opt/project/client-api-doc-server-new/static/public/upload/zip/${type2_info.day}/`,
          //构建布局名字
          jenkins_project_name: item.project == 1 ? "h5-sdk" : "pc-sdk",
          // day
          day: type2_info.day,
          //打包目标环境  1 试玩 ,2 生产
          env: item.env
        });
      }
    }
    // console.log("need_packup---------------------need_packup---------计算------",need_packup);
    // console.log("need_packup---------------------打包进程超时---------计算------",timeout_process);
    if (timeout_process.length > 0) {
      //删除 超时的  打包进程    timeout_process
      await this.ctx.model.PackingProcess.deleteMany({
        puck_up_record_id: { $in: timeout_process },
      });
    }
    // // http://127.0.0.1:18101/public/upload/yunwei/need_packup.json
    // // http://api-doc-server-new.sportxxxw1box.com/public/upload/yunwei/need_packup.json
    // // /opt/project/client-api-doc-server-new/static/public/upload/yunwei/need_packup.json
    // // 写入文件
    // let write_file_config = {
    //   needday: -1,
    //   data: need_packup,
    //   filename: "need_packup.json",
    //   type: "yunwei",
    //   extname: ".json",
    // };
    // // 把 要打包的 信息 写入文件
    // const write_file_result = await this.service.fileExport.write_file(
    //   write_file_config
    // );
    // //确保运维的 目录存在
    // let target_dir = `/static/public/upload/zip/${write_file_result.day}`;
    // console.log("__dirname", __dirname);
    // console.log("fs.existsSync(__dirname)", fs.existsSync(__dirname));
    // let target_dir_full_path = path.join(__dirname, "../../", target_dir);
    // console.log("fs.existsSync(__dirname)", target_dir_full_path);
    // if (!fs.existsSync(target_dir_full_path)) {
    //   fs.mkdirSync(target_dir_full_path);
    // }
    // await this.ctx.model.PackingProcess.insertMany(need_packup)
    return need_packup;
  }
  /**
   * 打包
   * 前端代码打包zip
   *
   */
  async pack_up_common_yunwei_zip(detail) {
    //计算需要打包的 数据 并写入 文件
    let need_packup = await this.service.packingUp.pack_up_compute_need_packup(
      detail
    );
    // 运维配置的 当前 要打包的数据的详细信息
    let packingProcess_info =
      need_packup.find((x) => x.full_version == detail.full_version) || {};
    //写入 打包进程
    await this.ctx.model.PackingProcess.create(packingProcess_info);
    //当前打包 的 记录的  基础数据的 差量化 数据 信息
    let detail_type2_info = detail.type2_info || {};
    // 记录当前  详细信息  更新 打包记录
    //打包类型  2 用户差异化配置文件
    let info = {
      // 基础名字
      base_name: detail_type2_info.base_name,
      // 文件全名 ，无 格式
      full_name: `${detail_type2_info.base_name}-3`,
      //打包类型
      type: "3",
      //day
      day: detail_type2_info.day,
      // 文件地址   日期202304091045189-uuid版本名字
      path: packingProcess_info.zip_file_full_path,
      //文件名字
      name: packingProcess_info.zip_file_full_name,
      //type
      type: "zip",
      //打包完成   -1 未完成 1 已完成 -2未完成强制取消
      finish: -1,
    };
    detail.type3_info = info;
    await detail.save();
    // console.log(
    //   `记录打包记录---打包  3 前端代码打包zip 下载  -------`,
    //   detail
    // );
  }
  /**
   * 打包
   * 前端代码打包zip
   *
   */
  pack_up_common_yunwei_jssdk() { }
  /**
   * 打包
   *
   * 打包需要输出 四个文件
   *
   * //打包类型  1 全量配置文件 2 用户差异化配置文件，      3.前端代码打包zip 下载    4 js sdk
   *
   */
  async pack_up(detail) {
    // version      username
    // 找到 配置记录  根据 去重之后  组合
    let type_arr = ("" + detail.type).split(",");
    console.log("记录打包记录----type_arr ------- ", type_arr);
    // 生成一条打包记录
    const PackingRecord_result =
      await this.service.packingUp.pack_up_common_create_record(detail);
    //打包类型  1 全量配置文件 2 用户差异化配置文件， 3.前端代码打包zip 下载  4 js sdk
    // 这四种类型都依赖于 类型 2   因此类型 2 必须打包
    // 打包类型 2 用户差异化配置文件
    // console.log( "记录打包记录----2 用户差异化配置文件 -------", );
    await this.service.packingUp.pack_up_common_chayihua_json(
      PackingRecord_result
    );
    // 打包类型  1 全量配置文件
    if (type_arr.includes("1")) {
      // console.log( "记录打包记录----1 全量配置文件 -------", );
      // await this.service.packingUp.pack_up_common_quanliang_json(
      //   PackingRecord_result
      // );
      await this.service.packingUp.pack_up_common_quanliang_json_new(
        PackingRecord_result
      );
    }
    // 打包类型 3 前端代码打包zip 下载
    if (type_arr.includes("3")) {
      // console.log( "记录打包记录---- 3 前端代码打包zip 下载 -------", );
      await this.service.packingUp.pack_up_common_yunwei_zip(
        PackingRecord_result
      );
    }
    // 打包类型 4 js sdk
    if (type_arr.includes("4")) {
      console.log("记录打包记录---- 4 js sdk-------");
      await this.service.packingUp.pack_up_common_yunwei_jssdk(
        PackingRecord_result
      );
    }
    console.log(
      "记录打包记录----PackingRecord_result._id -------",
      PackingRecord_result._id
    );
    //  记录打包记录
    const result = await this.ctx.model.PackingRecord.findById(
      PackingRecord_result._id
    );
    // console.log("记录打包记录----全部完成 -------", result);
    return result;
  }
  /**
   * 读取运维的 需要打包的文件内容
   * @returns
   */
  async read_need_packup_file() {
    let target_file = "static/public/upload/yunwei/need_packup.json";
    let target_file_full_path = path.join(__dirname, "../../", target_file);
    // console.log('fs.existsSync(__dirname)',target_dir_full_path);
    try {
      // let fie_path='/public/upload/yunwei/need_packup.json'
      let res = await fs.readFileSync(target_file_full_path).toString();
      res = JSON.parse(res);
      // console.log('读取 运维 打包文件 need_packup.json-----res--',res  );
      if (res && res.length) {
        return res;
      }
    } catch (error) {
      // console.log('读取 运维 打包文件 need_packup.json-------error--',error);
      return [];
    }
  }
  /**
   * 流程：
   *
   *  读取    /public/upload/yunwei/need_packup.json
   *  循环每个数据  扫 public/upload/zip/${day} 目录 确保 当前数据的 zip_file_name 在里面
   *
   *
   *    puck_up_record_id
   *     如果在  ， 更新对应的打包记录的数据 type3_info 状态
   *     否则 比较 puck_up_time  大于一个小时的 全部 状态 变为 -2
   *
   *
   *
   */
  async read_packed_file_and_change_finish_status() {
    // 打包进程
    let packingProcess = await this.ctx.model.PackingProcess.find({});
    // console.log('打包进-------packingProcess---',packingProcess.length);
    // 需要删除的打包进程
    let need_remove_process = [];
    let len = packingProcess.length;
    if (!len) {
      return false;
    }
    // "public/upload/zip/20230422
    //日期文件夹内容
    let day_folder = {};
    //所有数据的day
    let all_days = [];
    // 日期目录内的文件名字
    let day_folder_obj = {};
    for (let i = 0; i < len; i++) {
      let item = packingProcess[i];
      let day = item.day;
      let key = `day_${day}`;
      all_days.push(day);
      if (!day_folder[key]) {
        day_folder[key] = [];
      }
      day_folder[key].push(item.zip_file_full_name);
    }
    //所有数据的day
    all_days = Array.from(new Set(all_days));
    for (let i = 0; i < all_days.length; i++) {
      let folder = path.join(
        __dirname,
        "../../",
        `static/public/upload/zip/${all_days[i]}`
      );
      let key = `day_${all_days[i]}`;
      day_folder_obj[key] = [];

      let is_exist =   fs.existsSync(folder);
      if(is_exist){

        day_folder_obj[key] =   fs.readdirSync(folder);
      }

    }
    // //
    // console.log("日期文件夹内容----day_folder--------", day_folder);
    // console.log("所有数据的day ----all_days--------", all_days);
    // console.log(
    //   "日期目录内的文件名字 ----day_folder_obj--------",
    //   day_folder_obj
    // );
    // 循环遍历   packingProcess  判断每一个文件是否在  day_folder_obj[key] 内
    // 如果在  ， 更新对应的打包记录的数据 type3_info 状态
    // 如果不在   比较 puck_up_time  大于一个小时的 全部 状态 变为 -2
    for (let i = 0; i < packingProcess.length; i++) {
      let item = packingProcess[i];
      let { zip_file_full_name, day, puck_up_record_id, puck_up_time } = item;
      if (day_folder_obj[`day_${day}`].includes(zip_file_full_name)) {
        // 文件已存在  如果在  ， 更新对应的打包记录的数据 type3_info 状态
        // console.log('// 文件已存在  如果在  ， 更新对应的打包记录的数据 type3_info 状态----------');
        await this.ctx.model.PackingRecord.findByIdAndUpdate(
          puck_up_record_id,
          { "type3_info.finish": 1 }
        );
        // 需要删除的打包进程
        need_remove_process.push(item._id);
      } else {
        // console.log('如果不在   比较 puck_up_time  大于一个小时的 全部 状态 变为 -2----------');
        // 如果不在   比较 puck_up_time  大于一个小时的 全部 状态 变为 -2
        //如果时间大于 1小时强制结束
        let gt1 = Date.now() - puck_up_time > 60 * 60 * 1000;
        if (gt1) {
          //  console.log('如果不在   如果时间大于 1小时强制结束----------');
          await this.ctx.model.PackingRecord.findByIdAndUpdate(
            puck_up_record_id,
            { "type3_info.finish": -2 }
          );
          // 需要删除的打包进程
          need_remove_process.push(item._id);
        }
        // console.log('如果不在   如果时间   不到一个小时--------puck_up_record_id--' ,puck_up_record_id);
      }
    }
    // console.log( '需要删除的 打包进程',need_remove_process);
    if (need_remove_process.length) {
      // 删除 打包进程
      await this.ctx.model.PackingProcess.deleteMany({
        _id: { $in: need_remove_process },
      });
    }
  }
}
module.exports = PackingUpService;
